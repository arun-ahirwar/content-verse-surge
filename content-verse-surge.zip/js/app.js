/* Content Verse — Surge edition (static SPA + Supabase) */
(function () {
  'use strict';
  const CFG = window.CV_CONFIG;
  const sb = window.supabase.createClient(CFG.url, CFG.key, { auth: { persistSession: true, autoRefreshToken: true } });
  const app = document.getElementById('app');
  const PER_PAGE = 9;
  const SITE = (CFG.siteUrl || location.origin).replace(/\/$/, '');

  const S = { settings: {}, categories: [], session: null, profile: null, flash: null };

  // ---------- helpers ----------
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const plain = (html) => { const d = document.createElement('div'); d.innerHTML = DOMPurify.sanitize(String(html || '').replace(/<\/(p|h[1-6]|li|blockquote|div)>|<br\s*\/?>/gi, '$& ')); return (d.textContent || '').replace(/\s+/g, ' ').trim(); };
  const excerpt = (html, n = 170) => { const t = plain(html); return t.length > n ? `${t.slice(0, n).replace(/\s+\S*$/, '')}…` : t; };
  const readTime = (html) => Math.max(1, Math.round(plain(html).split(' ').filter(Boolean).length / 220));
  const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
  const initials = (n) => String(n || '?').split(/\s+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  const slugify = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90) || 'post';
  const safeUrl = (u) => (/^(https:\/\/|http:\/\/|\/)/.test(String(u || '').trim()) && !/["'<>\s]/.test(u) ? String(u).trim() : '');
  const clean = (html) => DOMPurify.sanitize(html || '', { ADD_TAGS: ['iframe'], ADD_ATTR: ['allowfullscreen', 'frameborder', 'target', 'allow'], FORBID_TAGS: ['style', 'form', 'input'] });
  const isAdmin = () => S.profile && S.profile.role === 'admin';
  const toast = (msg) => { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 3500); };
  const flash = (type, msg) => { S.flash = { type, msg }; };
  const takeFlash = () => { const f = S.flash; S.flash = null; return f; };
  const qs = () => new URLSearchParams(location.search);
  const pageNum = () => Math.max(1, parseInt(qs().get('page'), 10) || 1);

  function setTheme(admin) {
    document.getElementById('theme').href = admin ? '/css/admin.css' : '/css/site.css';
    document.body.className = admin ? 'adm' : '';
  }
  function setMeta({ title, desc, robots, image, type, canonical }) {
    const st = S.settings;
    document.title = title ? `${title} | ${st.site_title}` : `${st.site_title} — ${st.tagline}`;
    const set = (sel, attr, val) => { let el = document.head.querySelector(sel); if (!el) { el = document.createElement(sel.startsWith('link') ? 'link' : 'meta'); const m = sel.match(/\[(\w+(?::\w+)?)="([^"]+)"\]/); el.setAttribute(m[1], m[2]); document.head.appendChild(el); } el.setAttribute(attr, val); };
    const d = desc || st.tagline || '';
    set('meta[name="description"]', 'content', d);
    set('meta[name="robots"]', 'content', robots || 'index, follow, max-image-preview:large');
    set('link[rel="canonical"]', 'href', SITE + (canonical || location.pathname));
    set('meta[property="og:title"]', 'content', title || st.site_title);
    set('meta[property="og:description"]', 'content', d);
    set('meta[property="og:url"]', 'content', SITE + location.pathname);
    set('meta[property="og:type"]', 'content', type || 'website');
    if (image) set('meta[property="og:image"]', 'content', image);
  }

  // ---------- data ----------
  async function loadSettings() {
    const { data } = await sb.from('settings').select('key,value');
    S.settings = { site_title: 'Content Verse', tagline: '', footer_text: '', head_code: '', require_approval: '1', allow_registration: '1' };
    (data || []).forEach((r) => { S.settings[r.key] = r.value; });
  }
  async function loadCategories() {
    const [{ data: cats }, { data: pubs }] = await Promise.all([
      sb.from('categories').select('*').order('name'),
      sb.from('articles').select('category_id').eq('status', 'published').limit(10000),
    ]);
    const counts = {};
    (pubs || []).forEach((p) => { counts[p.category_id] = (counts[p.category_id] || 0) + 1; });
    S.categories = (cats || []).map((c) => ({ ...c, count: counts[c.id] || 0 }));
  }
  async function loadProfile() {
    const { data: { session } } = await sb.auth.getSession();
    S.session = session;
    S.profile = null;
    if (session) {
      const { data } = await sb.from('profiles').select('id,name,bio,role').eq('id', session.user.id).maybeSingle();
      S.profile = data ? { ...data, email: session.user.email } : { id: session.user.id, name: session.user.email, role: 'author', bio: '', email: session.user.email };
    }
  }
  const ART_SEL = 'id,title,slug,excerpt,content,featured_image,published_at,updated_at,views,status,tags,meta_title,meta_description,author_id,category_id,categories(name,slug,color),profiles(id,name,bio)';
  const norm = (a) => ({ ...a, cat_name: a.categories && a.categories.name, cat_slug: a.categories && a.categories.slug, cat_color: a.categories && a.categories.color, author_name: (a.profiles && a.profiles.name) || 'Writer', author_bio: a.profiles && a.profiles.bio });

  async function listArticles(filter, page) {
    let q = sb.from('articles').select(ART_SEL, { count: 'exact' }).eq('status', 'published');
    q = filter ? filter(q) : q;
    const from = (page - 1) * PER_PAGE;
    const { data, count, error } = await q.order('published_at', { ascending: false }).range(from, from + PER_PAGE - 1);
    if (error) throw error;
    return { articles: (data || []).map(norm), page, pages: Math.max(1, Math.ceil((count || 0) / PER_PAGE)), total: count || 0 };
  }

  // ---------- public templates ----------
  function header() {
    const st = S.settings; const u = S.profile; const p = location.pathname;
    return `<a class="skip" href="#main">Skip to content</a>
<header class="topbar"><div class="wrap topbar__in">
  <a class="logo" href="/"><span class="logo__mark" aria-hidden="true"><i></i></span><span class="logo__text">${esc(st.site_title)}</span></a>
  <form class="search" action="/search" method="get" role="search" data-search><input type="search" name="q" placeholder="Search stories…" aria-label="Search articles" value="${esc(p === '/search' ? qs().get('q') || '' : '')}"><button aria-label="Search"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button></form>
  <nav class="acct">${u ? `<a class="btn btn--ghost" href="/admin">Dashboard</a><a class="btn btn--accent" href="/admin/articles/new">+ Write</a>`
    : `<a class="btn btn--ghost" href="/login">Log in</a>${st.allow_registration === '1' ? '<a class="btn btn--accent" href="/register">Start writing</a>' : ''}`}</nav>
</div>
<nav class="catnav" aria-label="Categories"><div class="wrap catnav__in"><a href="/" class="${p === '/' ? 'on' : ''}">All</a>
${S.categories.map((c) => `<a href="/category/${esc(c.slug)}" style="--c:${esc(c.color)}" class="${p === `/category/${c.slug}` ? 'on' : ''}"><i></i>${esc(c.name)}</a>`).join('')}</div></nav></header><main id="main">`;
  }
  function footer() {
    const st = S.settings;
    return `</main><footer class="foot"><div class="wrap foot__grid"><div>
  <a class="logo logo--light" href="/"><span class="logo__mark" aria-hidden="true"><i></i></span><span class="logo__text">${esc(st.site_title)}</span></a>
  <p class="foot__lead">${esc(st.footer_text)}</p>${st.allow_registration === '1' ? '<a class="btn btn--accent" href="/register">Become a writer →</a>' : ''}</div>
  <div><h4>Explore</h4><ul>${S.categories.slice(0, 8).map((c) => `<li><a href="/category/${esc(c.slug)}">${esc(c.name)}</a></li>`).join('')}</ul></div>
  <div><h4>Writers</h4><ul><li><a href="/register">Create account</a></li><li><a href="/login">Log in</a></li><li><a href="/admin/articles/new">Write an article</a></li></ul></div>
</div><div class="wrap foot__base">© ${new Date().getFullYear()} ${esc(st.site_title)}. All rights reserved.</div></footer>`;
  }
  const pub = (inner) => { setTheme(false); app.innerHTML = header() + inner + footer(); };

  function card(a, big) {
    return `<article class="card ${big ? 'card--big' : ''}" style="--c:${esc(a.cat_color || '#6c4cff')}">
  <a class="card__media" href="/article/${esc(a.slug)}" tabindex="-1" aria-hidden="true">${safeUrl(a.featured_image) ? `<img src="${esc(safeUrl(a.featured_image))}" alt="" loading="lazy">` : `<span class="card__ph"><b>${esc((a.title || '?').trim().charAt(0).toUpperCase())}</b></span>`}</a>
  <div class="card__body">${a.cat_name ? `<a class="chip" href="/category/${esc(a.cat_slug)}">${esc(a.cat_name)}</a>` : ''}
    <h3 class="card__title"><a href="/article/${esc(a.slug)}">${esc(a.title)}</a></h3>
    ${big ? `<p class="card__ex">${esc(a.excerpt || excerpt(a.content))}</p>` : ''}
    <div class="meta"><span class="avatar">${esc(initials(a.author_name))}</span><a href="/author/${esc(a.author_id)}">${esc(a.author_name)}</a><span>·</span><span>${fmtDate(a.published_at)}</span><span>·</span><span>${readTime(a.content)} min read</span></div>
  </div></article>`;
  }
  function pager(d, base) {
    if (d.pages <= 1) return '';
    const sep = base.includes('?') ? '&' : '?';
    return `<nav class="pager">${d.page > 1 ? `<a href="${base}${sep}page=${d.page - 1}">← Newer</a>` : ''}<span>Page ${d.page} of ${d.pages}</span>${d.page < d.pages ? `<a href="${base}${sep}page=${d.page + 1}">Older →</a>` : ''}</nav>`;
  }

  async function viewHome() {
    const page = pageNum();
    const [d, pop] = await Promise.all([listArticles(null, page), sb.from('articles').select(ART_SEL).eq('status', 'published').order('views', { ascending: false }).limit(5)]);
    const popular = (pop.data || []).map(norm);
    const st = S.settings; const u = S.profile;
    const planets = S.categories.slice(0, 8);
    setMeta({ canonical: '/' });
    pub(`<section class="hero"><div class="wrap hero__grid"><div class="hero__copy">
  <p class="kicker">Welcome to ${esc(st.site_title)}</p><h1>A universe of stories for <em>better living.</em></h1>
  <p class="hero__lead">${esc(st.tagline)}</p>
  <div class="hero__cta"><a class="btn btn--dark btn--lg" href="#latest" data-noroute>Start reading</a>${u ? '<a class="btn btn--line btn--lg" href="/admin/articles/new">Write a new article</a>' : st.allow_registration === '1' ? '<a class="btn btn--line btn--lg" href="/register">Publish your story</a>' : ''}</div></div>
  <div class="orbit"><div class="orbit__core"><span>${d.total}</span><small>stories</small></div><div class="orbit__ring r1"></div><div class="orbit__ring r2"></div><div class="orbit__ring r3"></div>
  <div class="orbit__spin">${planets.map((c, i) => `<a class="planet" href="/category/${esc(c.slug)}" style="--c:${esc(c.color)}; --a:${(360 / planets.length) * i}deg; --r:${i % 2 ? 'var(--r2)' : 'var(--r3)'}"><span><i></i>${esc(c.name)}</span></a>`).join('')}</div></div>
</div></section>
<section class="wrap" id="latest">${!d.articles.length ? `<div class="empty"><h2>The universe is waiting for its first story.</h2><p>No articles have been published yet. Be the first to write one.</p><a class="btn btn--accent btn--lg" href="/admin/articles/new">Write the first article</a></div>`
    : `<div class="sec-head"><h2>Latest stories</h2><span class="line"></span></div><div class="layout"><div>
  ${page === 1 ? card(d.articles[0], true) : ''}<div class="grid">${d.articles.slice(page === 1 ? 1 : 0).map((a) => card(a)).join('')}</div>${pager(d, '/')}</div>
  <aside class="side"><div class="box"><h3>Trending now</h3><ol class="trend">${popular.map((p, i) => `<li><span class="num">0${i + 1}</span><div><a href="/article/${esc(p.slug)}">${esc(p.title)}</a><small>${esc(p.cat_name || 'Uncategorized')}</small></div></li>`).join('')}</ol></div>
  <div class="box"><h3>Topics</h3><div class="topics">${S.categories.map((c) => `<a href="/category/${esc(c.slug)}" style="--c:${esc(c.color)}">${esc(c.name)} <b>${c.count}</b></a>`).join('')}</div></div>
  ${!u && st.allow_registration === '1' ? `<div class="box box--cta"><h3>Got something to share?</h3><p>Create a free account and publish articles on ${esc(st.site_title)}.</p><a class="btn btn--accent" href="/register">Join as a writer</a></div>` : ''}</aside></div>`}</section>`);
  }

  function listPage({ kicker, heading, sub, color, d, base }) {
    pub(`<section class="band" style="--c:${esc(color || '#6c4cff')}"><div class="wrap"><p class="kicker">${esc(kicker)}</p><h1>${esc(heading)}</h1>${sub ? `<p class="band__sub">${esc(sub)}</p>` : ''}</div></section>
<section class="wrap list-wrap">${!d.articles.length ? '<div class="empty"><h2>Nothing here yet.</h2><p>No published articles found. Check back soon!</p><a class="btn btn--dark" href="/">Back to home</a></div>'
    : `<div class="grid grid--3">${d.articles.map((a) => card(a)).join('')}</div>${pager(d, base)}`}</section>`);
  }
  async function viewCategory(slug) {
    const c = S.categories.find((x) => x.slug === slug);
    if (!c) return viewNotFound();
    const d = await listArticles((q) => q.eq('category_id', c.id), pageNum());
    setMeta({ title: c.name, desc: c.description });
    listPage({ kicker: 'Category', heading: c.name, sub: c.description, color: c.color, d, base: `/category/${slug}` });
  }
  async function viewAuthor(id) {
    const { data: p } = await sb.from('profiles').select('id,name,bio').eq('id', id).maybeSingle();
    if (!p) return viewNotFound();
    const d = await listArticles((q) => q.eq('author_id', id), pageNum());
    setMeta({ title: p.name, desc: p.bio || `Articles by ${p.name}` });
    listPage({ kicker: 'Author', heading: p.name, sub: p.bio || `Articles written by ${p.name}.`, d, base: `/author/${id}` });
  }
  async function viewSearch() {
    const term = (qs().get('q') || '').trim().slice(0, 80);
    const t = term.replace(/[,()%*\\]/g, ' ');
    let d = { articles: [], page: 1, pages: 1, total: 0 };
    if (t.trim()) d = await listArticles((q) => q.or(`title.ilike.%${t}%,content.ilike.%${t}%,tags.ilike.%${t}%`), pageNum());
    setMeta({ title: `Search: ${term}`, robots: 'noindex, follow' });
    listPage({ kicker: 'Search', heading: term ? `“${term}”` : 'Search', sub: `${d.total} result${d.total === 1 ? '' : 's'} found`, d, base: `/search?q=${encodeURIComponent(term)}` });
  }
  async function viewArticle(slug) {
    const { data } = await sb.from('articles').select(ART_SEL).eq('slug', slug).maybeSingle();
    if (!data) return viewNotFound();
    const a = norm(data);
    const preview = a.status !== 'published';
    if (!preview) sb.rpc('increment_views', { p_slug: slug }).then(() => {});
    const { data: rel } = await sb.from('articles').select(ART_SEL).eq('status', 'published').neq('id', a.id).eq('category_id', a.category_id || -1).order('published_at', { ascending: false }).limit(3);
    const related = (rel || []).map(norm);
    const url = `${SITE}/article/${a.slug}`;
    const img = safeUrl(a.featured_image);
    setMeta({ title: a.meta_title || a.title, desc: a.meta_description || a.excerpt || excerpt(a.content), type: 'article', image: img, robots: preview ? 'noindex' : null });
    pub(`${preview ? `<div class="preview-bar">Preview — this article is <b>${esc(a.status)}</b> and not visible to the public. <a href="/admin/articles/${a.id}/edit">Back to editor</a></div>` : ''}
<article class="post" style="--c:${esc(a.cat_color || '#6c4cff')}"><header class="post__head wrap wrap--narrow">
  <nav class="crumbs"><a href="/">Home</a> / ${a.cat_name ? `<a href="/category/${esc(a.cat_slug)}">${esc(a.cat_name)}</a>` : 'Uncategorized'}</nav>
  ${a.cat_name ? `<a class="chip" href="/category/${esc(a.cat_slug)}">${esc(a.cat_name)}</a>` : ''}<h1>${esc(a.title)}</h1>
  ${a.excerpt ? `<p class="post__dek">${esc(a.excerpt)}</p>` : ''}
  <div class="meta meta--lg"><span class="avatar">${esc(initials(a.author_name))}</span><div><a href="/author/${esc(a.author_id)}"><b>${esc(a.author_name)}</b></a><br><span>${fmtDate(a.published_at || a.updated_at)} · ${readTime(a.content)} min read</span></div></div></header>
  ${img ? `<figure class="post__hero wrap"><img src="${esc(img)}" alt="${esc(a.title)}"></figure>` : ''}
  <div class="wrap wrap--narrow"><div class="prose">${clean(a.content)}</div>
  ${a.tags ? `<div class="tags">${a.tags.split(',').map((t) => t.trim()).filter(Boolean).map((t) => `<a href="/search?q=${encodeURIComponent(t)}">#${esc(t)}</a>`).join('')}</div>` : ''}
  <div class="share"><span>Share:</span><a target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(`${a.title} ${url}`)}">WhatsApp</a><a target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(a.title)}">X</a><a target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}">Facebook</a><a target="_blank" rel="noopener" href="https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}">LinkedIn</a></div>
  <div class="authorbox"><span class="avatar avatar--lg">${esc(initials(a.author_name))}</span><div><small>Written by</small><h3><a href="/author/${esc(a.author_id)}">${esc(a.author_name)}</a></h3><p>${esc(a.author_bio || `Writer at ${S.settings.site_title}.`)}</p></div></div></div></article>
${related.length ? `<section class="wrap related"><div class="sec-head"><h2>Keep reading</h2><span class="line"></span></div><div class="grid grid--3">${related.map((r) => card(r)).join('')}</div></section>` : ''}`);
    const ld = document.createElement('script'); ld.type = 'application/ld+json';
    ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'Article', headline: a.title, description: a.meta_description || a.excerpt, image: img ? [img] : undefined, datePublished: a.published_at, dateModified: a.updated_at, author: { '@type': 'Person', name: a.author_name }, publisher: { '@type': 'Organization', name: S.settings.site_title }, mainEntityOfPage: url });
    app.appendChild(ld);
  }
  function viewNotFound() {
    setMeta({ title: 'Page not found', robots: 'noindex' });
    pub('<section class="wrap empty empty--404"><p class="big404">404</p><h1>This page drifted out of orbit.</h1><p>The page you’re looking for doesn’t exist or has been moved.</p><a class="btn btn--dark btn--lg" href="/">Back to home</a></section>');
  }

  // ---------- auth ----------
  function viewAuth(mode) {
    if (S.profile) return go('/admin', true);
    if (mode === 'register' && S.settings.allow_registration !== '1') { flash('error', 'New registrations are currently closed.'); mode = 'login'; }
    const st = S.settings; const f = takeFlash();
    setTheme(false); setMeta({ title: mode === 'login' ? 'Log in' : 'Create account', robots: 'noindex, follow' });
    app.innerHTML = `<div class="auth"><div class="auth__art"><a class="logo logo--light" href="/"><span class="logo__mark" aria-hidden="true"><i></i></span><span class="logo__text">${esc(st.site_title)}</span></a>
  <div class="auth__orbit" aria-hidden="true"><span></span><span></span><span></span><b></b></div>
  <h2>${mode === 'login' ? 'Welcome back, storyteller.' : 'Your words deserve a universe.'}</h2><p>Write about furniture, home & decor, health, fitness, electronics and more — and reach readers everywhere.</p></div>
<div class="auth__form"><form class="formcard" id="authForm"><h1>${mode === 'login' ? 'Log in' : 'Create your account'}</h1>
  <p class="muted">${mode === 'login' ? 'Access your dashboard to write and manage articles.' : 'Free forever. Start publishing in a minute.'}</p>
  <div id="authMsg">${f ? `<div class="alert alert--${f.type}">${esc(f.msg)}</div>` : ''}</div>
  ${mode === 'register' ? '<label>Full name<input name="name" required maxlength="80" autocomplete="name"></label>' : ''}
  <label>Email<input type="email" name="email" required autocomplete="email"></label>
  <label>Password<input type="password" name="password" required minlength="${mode === 'register' ? 8 : 1}" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}"></label>
  <button class="btn btn--accent btn--lg btn--block">${mode === 'login' ? 'Log in' : 'Create account'}</button>
  <p class="switch">${mode === 'login' ? 'New here? <a href="/register">Create an account</a>' : 'Already a member? <a href="/login">Log in</a>'}</p>
  ${mode === 'login' ? '<p class="switch"><a href="#" id="forgot">Forgot password?</a></p>' : ''}
  <a class="back" href="/">← Back to ${esc(st.site_title)}</a></form></div></div>`;
    const form = document.getElementById('authForm'); const msg = document.getElementById('authMsg');
    const show = (type, t) => { msg.innerHTML = `<div class="alert alert--${type}">${esc(t)}</div>`; };
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form); const btn = form.querySelector('button'); btn.disabled = true;
      try {
        if (mode === 'login') {
          const { error } = await sb.auth.signInWithPassword({ email: fd.get('email').trim(), password: fd.get('password') });
          if (error) throw error;
          await loadProfile();
          const next = qs().get('next');
          go(next && next.startsWith('/') && !next.startsWith('//') ? next : '/admin', true);
        } else {
          const { data, error } = await sb.auth.signUp({ email: fd.get('email').trim(), password: fd.get('password'), options: { data: { name: fd.get('name').trim() }, emailRedirectTo: `${location.origin}/admin` } });
          if (error) throw error;
          if (data.session) { await loadProfile(); flash('success', `Welcome to ${st.site_title}, ${fd.get('name')}! Start writing your first article.`); go('/admin', true); }
          else { form.reset(); show('success', 'Account created! We sent a confirmation link to your email — click it, then log in.'); }
        }
      } catch (err) {
        show('error', /Invalid login/i.test(err.message) ? 'Email or password is incorrect.' : /not confirmed/i.test(err.message) ? 'Please confirm your email first — check your inbox for the link.' : err.message);
      }
      btn.disabled = false;
    });
    const fg = document.getElementById('forgot');
    if (fg) fg.addEventListener('click', async (e) => {
      e.preventDefault();
      const email = form.email.value.trim();
      if (!email) return show('error', 'Type your email above first, then click “Forgot password?”.');
      const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/admin/profile` });
      show(error ? 'error' : 'success', error ? error.message : 'Password reset link sent — check your email.');
    });
  }

  // ---------- admin ----------
  function adminShell(title, inner) {
    setTheme(true); setMeta({ title, robots: 'noindex, nofollow' });
    const p = location.pathname; const u = S.profile; const f = takeFlash();
    const nav = (href, label, icon, exact) => `<a href="${href}" class="${(exact ? p === href : p.startsWith(href)) ? 'on' : ''}"><span class="ico">${icon}</span>${label}</a>`;
    app.innerHTML = `<input type="checkbox" id="navtoggle" hidden><aside class="sidebar">
  <a class="brand" href="/admin"><span class="brand__dot"></span><span>${esc(S.settings.site_title)}<small>${isAdmin() ? 'Admin panel' : 'Writer studio'}</small></span></a>
  <nav>${nav('/admin', 'Dashboard', '◎', true)}<p class="navlabel">Content</p>${nav('/admin/articles/new', 'Add New Article', '✎', true)}
  <a href="/admin/articles" class="${p === '/admin/articles' || /^\/admin\/articles\/\d+/.test(p) ? 'on' : ''}"><span class="ico">☰</span>${isAdmin() ? 'All Articles' : 'My Articles'}</a>
  ${isAdmin() ? `${nav('/admin/categories', 'Categories', '◈')}<p class="navlabel">Manage</p>${nav('/admin/users', 'Users', '☺')}${nav('/admin/settings', 'Settings & SEO', '⚙')}` : ''}
  <p class="navlabel">Account</p>${nav('/admin/profile', 'Profile', '◐')}<a href="/" target="_blank"><span class="ico">↗</span>View website</a>
  <button id="logout"><span class="ico">⏻</span>Log out</button></nav></aside>
<div class="main"><header class="bar"><label for="navtoggle" class="burger">☰</label><h1>${esc(title)}</h1>
  <div class="bar__user"><span class="av">${esc(initials(u.name))}</span><div><b>${esc(u.name)}</b><small>${isAdmin() ? 'Administrator' : 'Author'}</small></div></div></header>
<div class="content">${f ? `<div class="notice notice--${f.type}">${esc(f.msg)}</div>` : ''}${inner}</div></div>`;
    document.getElementById('logout').addEventListener('click', async () => { await sb.auth.signOut(); S.profile = null; go('/', true); });
  }
  const denied = () => adminShell('Not allowed', '<section class="panel"><p class="empty">Only administrators can open this page. <a href="/admin">Back to dashboard</a></p></section>');

  async function myArticles(cols) {
    let q = sb.from('articles').select(cols);
    if (!isAdmin()) q = q.eq('author_id', S.profile.id);
    return q;
  }

  async function viewDashboard() {
    const { data } = await (await myArticles('id,title,slug,status,views,updated_at,categories(name),profiles(name)')).order('updated_at', { ascending: false }).limit(1000);
    const rows = data || [];
    const c = { published: 0, draft: 0, pending: 0, views: 0 };
    rows.forEach((r) => { c[r.status] += 1; c.views += r.views || 0; });
    let usersCount = null;
    if (isAdmin()) { const { data: us } = await sb.rpc('admin_users'); usersCount = (us || []).length; }
    const st = S.settings;
    adminShell('Dashboard', `<section class="welcome"><div><p class="eyebrow">Hello, ${esc(S.profile.name.split(' ')[0])} 👋</p><h2>What will you publish today?</h2>
  <p>${isAdmin() ? 'Manage every article, category and writer on your site from here.' : st.require_approval === '1' ? 'Write your article and submit it — an admin will review and publish it.' : 'Write your article and publish it straight to the website.'}</p></div>
  <a class="btn btn--accent btn--lg" href="/admin/articles/new">✎ Write new article</a></section>
<section class="stats"><a class="stat" href="/admin/articles?status=published" style="--c:#2f9e6e"><small>Published</small><b>${c.published}</b></a>
  <a class="stat" href="/admin/articles?status=draft" style="--c:#4f5bd5"><small>Drafts</small><b>${c.draft}</b></a>
  <a class="stat" href="/admin/articles?status=pending" style="--c:#ff9f1c"><small>Pending review</small><b>${c.pending}</b></a>
  <div class="stat" style="--c:#ff5a36"><small>Total views</small><b>${c.views.toLocaleString('en-IN')}</b></div>
  ${usersCount !== null ? `<a class="stat" href="/admin/users" style="--c:#d64f7a"><small>Writers</small><b>${usersCount}</b></a>` : ''}</section>
<div class="cols"><section class="panel"><div class="panel__head"><h3>Recent activity</h3><a href="/admin/articles">View all →</a></div>
  ${!rows.length ? '<p class="empty">No articles yet. <a href="/admin/articles/new">Write your first one</a>.</p>' : ''}
  <table class="tbl">${rows.slice(0, 8).map((r) => `<tr><td><a class="t" href="/admin/articles/${r.id}/edit">${esc(r.title)}</a><small>${esc((r.categories && r.categories.name) || 'Uncategorized')}${isAdmin() ? ` · by ${esc(r.profiles && r.profiles.name)}` : ''}</small></td><td><span class="pill pill--${r.status}">${r.status}</span></td><td class="dim">${fmtDate(r.updated_at)}</td></tr>`).join('')}</table></section>
<section class="panel"><div class="panel__head"><h3>Quick links</h3></div><div class="quick"><a href="/admin/articles?status=draft">📝 Continue a draft</a>
  ${isAdmin() ? '<a href="/admin/articles?status=pending">⏳ Review pending articles</a><a href="/admin/categories">◈ Add a category</a><a href="/admin/settings">⚙ Site settings & SEO</a>' : ''}
  <a href="/admin/profile">◐ Edit your author bio</a><a href="/" target="_blank">↗ Open the website</a></div></section></div>`);
  }

  async function viewArticlesList() {
    const status = ['published', 'draft', 'pending'].includes(qs().get('status')) ? qs().get('status') : '';
    const term = (qs().get('q') || '').trim();
    const { data } = await (await myArticles('id,title,slug,status,views,updated_at,published_at,categories(name,color),profiles(name)')).order('updated_at', { ascending: false }).limit(1000);
    const all = data || [];
    const counts = { all: all.length, published: 0, draft: 0, pending: 0 };
    all.forEach((r) => { counts[r.status] += 1; });
    const rows = all.filter((r) => (!status || r.status === status) && (!term || r.title.toLowerCase().includes(term.toLowerCase())));
    const tab = (s, label) => `<a href="/admin/articles${s ? `?status=${s}` : ''}" class="${status === s ? 'on' : ''}">${label} <b>${counts[s || 'all']}</b></a>`;
    adminShell('Articles', `<div class="toolbar"><nav class="tabs">${tab('', 'All')}${tab('published', 'Published')}${tab('draft', 'Drafts')}${tab('pending', 'Pending')}</nav>
  <form class="find" id="findForm"><input type="search" name="q" value="${esc(term)}" placeholder="Search articles…"><button class="btn btn--dark">Search</button></form>
  <a class="btn btn--accent" href="/admin/articles/new">+ Add New</a></div>
<section class="panel">${!rows.length ? '<p class="empty">No articles found. <a href="/admin/articles/new">Write a new article</a>.</p>' : `<table class="tbl tbl--full">
  <thead><tr><th>Title</th>${isAdmin() ? '<th>Author</th>' : ''}<th>Category</th><th>Status</th><th>Views</th><th>Date</th></tr></thead><tbody>
  ${rows.map((a) => `<tr><td><a class="t" href="/admin/articles/${a.id}/edit">${esc(a.title)}</a><div class="rowact">
    <a href="/admin/articles/${a.id}/edit">Edit</a><a href="/article/${esc(a.slug)}" target="_blank">${a.status === 'published' ? 'View' : 'Preview'}</a>
    ${isAdmin() && a.status !== 'published' ? `<button class="ok" data-status="published" data-id="${a.id}">Publish</button>` : ''}
    ${isAdmin() && a.status === 'published' ? `<button data-status="draft" data-id="${a.id}">Unpublish</button>` : ''}
    <button class="del" data-del="${a.id}">Delete</button></div></td>
    ${isAdmin() ? `<td>${esc(a.profiles && a.profiles.name)}</td>` : ''}
    <td>${a.categories ? `<span class="dot" style="--c:${esc(a.categories.color)}"></span>${esc(a.categories.name)}` : '<span class="dim">—</span>'}</td>
    <td><span class="pill pill--${a.status}">${a.status}</span></td><td>${a.views}</td>
    <td class="dim">${a.status === 'published' ? 'Published' : 'Modified'}<br>${fmtDate(a.status === 'published' ? a.published_at : a.updated_at)}</td></tr>`).join('')}</tbody></table>`}</section>`);
    document.getElementById('findForm').addEventListener('submit', (e) => { e.preventDefault(); const q = e.target.q.value.trim(); go(`/admin/articles?${new URLSearchParams({ ...(status ? { status } : {}), ...(q ? { q } : {}) })}`); });
    app.querySelectorAll('[data-status]').forEach((b) => b.addEventListener('click', async () => {
      const { error } = await sb.from('articles').update({ status: b.dataset.status }).eq('id', b.dataset.id);
      if (error) return toast(error.message);
      flash('success', `Article marked as ${b.dataset.status}.`); await loadCategories(); route();
    }));
    app.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      if (!window.confirm('Delete this article permanently?')) return;
      const { error } = await sb.from('articles').delete().eq('id', b.dataset.del);
      if (error) return toast(error.message);
      flash('success', 'Article deleted.'); await loadCategories(); route();
    }));
  }

  async function uploadImage(file) {
    if (!/^image\/(png|jpe?g|gif|webp|avif)$/.test(file.type)) throw new Error('Please upload a JPG, PNG, GIF or WEBP image.');
    if (file.size > 4 * 1024 * 1024) throw new Error('Image must be smaller than 4 MB.');
    const name = `${S.profile.id}/${Date.now()}-${slugify(file.name.replace(/\.[^.]+$/, ''))}.${(file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '')}`;
    const { error } = await sb.storage.from('media').upload(name, file, { contentType: file.type, cacheControl: '31536000' });
    if (error) throw error;
    return sb.storage.from('media').getPublicUrl(name).data.publicUrl;
  }

  async function uniqueSlug(base, excludeId) {
    const root = slugify(base); let slug = root; let i = 1;
    for (;;) {
      let q = sb.from('articles').select('id').eq('slug', slug);
      if (excludeId) q = q.neq('id', excludeId);
      const { data } = await q;
      if (!data || !data.length) return slug;
      i += 1; slug = `${root}-${i}`;
    }
  }

  async function viewEditor(id) {
    let a = { id: null, title: '', slug: '', content: '', excerpt: '', featured_image: '', category_id: null, tags: '', meta_title: '', meta_description: '', status: 'draft', published_at: null };
    if (id) {
      const { data } = await sb.from('articles').select('*').eq('id', id).maybeSingle();
      if (!data || (!isAdmin() && data.author_id !== S.profile.id)) return viewNotFound();
      a = data;
    }
    const needsReview = !isAdmin() && S.settings.require_approval === '1';
    const host = SITE.replace(/^https?:\/\//, '');
    adminShell(id ? 'Edit Article' : 'Add New Article', `<form id="postForm" class="editor"><div class="editor__main">
  <input class="titlebox" name="title" id="title" value="${esc(a.title)}" placeholder="Add title" required maxlength="200" autocomplete="off">
  <div class="permalink"><b>Permalink:</b> <span>${esc(SITE)}/article/</span><input name="slug" id="slug" value="${esc(a.slug)}" placeholder="auto-from-title">${id ? `<a href="/article/${esc(a.slug)}" target="_blank" class="btn btn--sm">View</a>` : ''}</div>
  <div class="mediabar"><button type="button" class="btn btn--sm btn--line" id="addMedia"><span>🖼</span><span> Add Media</span></button><input type="file" id="mediaFile" accept="image/*" hidden>
    <div class="vt"><button type="button" class="on" data-mode="visual">Visual</button><button type="button" data-mode="text">Text</button></div></div>
  <div class="editwrap"><textarea name="content" id="content">${esc(a.content)}</textarea></div><div class="wordcount" id="wc">Word count: 0</div>
  <details class="mbox" open><summary>Excerpt</summary><div class="mbox__in"><textarea name="excerpt" rows="3" maxlength="400" placeholder="Short summary shown on cards and under the title (optional — auto-generated if empty)">${esc(a.excerpt)}</textarea></div></details>
  <details class="mbox" open><summary>SEO — Google snippet</summary><div class="mbox__in">
    <label>SEO title <small class="cnt" data-for="meta_title" data-max="60"></small><input name="meta_title" id="meta_title" value="${esc(a.meta_title)}" maxlength="120" placeholder="Defaults to the article title"></label>
    <label>Meta description <small class="cnt" data-for="meta_description" data-max="160"></small><textarea name="meta_description" id="meta_description" rows="2" maxlength="300" placeholder="Defaults to the excerpt">${esc(a.meta_description)}</textarea></label>
    <div class="serp"><small>${esc(host)} › article › <span id="serpSlug">${esc(a.slug || '…')}</span></small><b id="serpTitle">${esc(a.meta_title || a.title || 'Your article title')}</b><p id="serpDesc">${esc(a.meta_description || a.excerpt || 'Your meta description will appear here in Google search results.')}</p></div></div></details>
</div><aside class="editor__side">
  <div class="mbox mbox--pub"><div class="mbox__t">Publish</div><div class="mbox__in">
    <div class="pubrow"><button type="submit" data-action="draft" class="btn btn--sm btn--line">Save Draft</button>${id ? `<a class="btn btn--sm btn--line" href="/article/${esc(a.slug)}" target="_blank">Preview</a>` : ''}</div>
    <ul class="pubinfo"><li>Status: <span class="pill pill--${a.status}">${a.status}</span></li><li>Visibility: <b>Public</b></li>${a.published_at ? `<li>Published on: <b>${fmtDate(a.published_at)}</b></li>` : ''}</ul>
    ${needsReview ? '<p class="hint">Your article will be reviewed by an admin before it goes live.</p>' : ''}</div>
    <div class="mbox__foot">${id ? '<button type="button" class="trash" id="trash">Move to Trash</button>' : '<span></span>'}
    ${a.status === 'published' ? '<button type="submit" data-action="update" class="btn btn--accent">Update</button>' : `<button type="submit" data-action="publish" class="btn btn--accent">${needsReview ? 'Submit for Review' : 'Publish'}</button>`}</div></div>
  <div class="mbox"><div class="mbox__t">Category</div><div class="mbox__in catlist"><label><input type="radio" name="category_id" value="" ${!a.category_id ? 'checked' : ''}> Uncategorized</label>
    ${S.categories.map((c) => `<label><input type="radio" name="category_id" value="${c.id}" ${a.category_id === c.id ? 'checked' : ''}> <span class="dot" style="--c:${esc(c.color)}"></span>${esc(c.name)}</label>`).join('')}
    ${isAdmin() ? '<a class="addlink" href="/admin/categories" target="_blank">+ Add New Category</a>' : ''}</div></div>
  <div class="mbox"><div class="mbox__t">Tags</div><div class="mbox__in"><input name="tags" value="${esc(a.tags)}" placeholder="sofa, living room, budget"><p class="hint">Separate tags with commas.</p></div></div>
  <div class="mbox"><div class="mbox__t">Featured Image</div><div class="mbox__in"><input type="hidden" name="featured_image" id="featured_image" value="${esc(a.featured_image)}">
    <div class="fimg" id="fimgPreview">${safeUrl(a.featured_image) ? `<img src="${esc(a.featured_image)}" alt="">` : ''}</div><input type="file" id="fimgFile" accept="image/*" hidden>
    <button type="button" class="linkbtn" id="fimgSet">${a.featured_image ? 'Replace featured image' : 'Set featured image'}</button>
    <button type="button" class="linkbtn linkbtn--del" id="fimgRemove" ${a.featured_image ? '' : 'hidden'}>Remove featured image</button>
    <p class="hint">Or paste an image URL: <input id="fimgUrl" placeholder="https://…"></p></div></div>
</aside></form>`);
    if (!window.tinymce) await new Promise((res, rej) => { const sc = document.createElement('script'); sc.src = '/vendor/tinymce/tinymce.min.js'; sc.onload = res; sc.onerror = () => rej(new Error('Editor failed to load')); document.head.appendChild(sc); });
    window.CVEditor.mount({ uploadImage, onSave: (fields, action) => saveArticle(a, fields, action), onTrash: async () => {
      if (!window.confirm('Move this article to trash? This deletes it permanently.')) return;
      const { error } = await sb.from('articles').delete().eq('id', a.id);
      if (error) return toast(error.message);
      flash('success', 'Article deleted.'); await loadCategories(); go('/admin/articles');
    } });
  }

  async function saveArticle(a, f, action) {
    const content = clean(f.content);
    const row = {
      title: (f.title || '').trim().slice(0, 200) || 'Untitled',
      content,
      excerpt: (f.excerpt || '').trim().slice(0, 400) || excerpt(content),
      category_id: parseInt(f.category_id, 10) || null,
      featured_image: safeUrl(f.featured_image),
      tags: String(f.tags || '').split(',').map((t) => t.trim()).filter(Boolean).slice(0, 15).join(', '),
      meta_title: (f.meta_title || '').trim().slice(0, 120),
      meta_description: (f.meta_description || '').trim().slice(0, 300),
    };
    row.slug = await uniqueSlug((f.slug || '').trim() || row.title, a.id);
    if (action === 'publish') row.status = 'published';
    else if (action === 'draft') row.status = 'draft';
    else row.status = a.status;
    const res = a.id ? await sb.from('articles').update(row).eq('id', a.id).select('id,status').single()
      : await sb.from('articles').insert(row).select('id,status').single();
    if (res.error) { toast(res.error.message); return false; }
    const msgs = { published: 'Article published! It is now live on the website.', pending: 'Article submitted for review. An admin will publish it soon.', draft: 'Draft saved.' };
    flash('success', action === 'update' && res.data.status === 'published' ? 'Article updated.' : msgs[res.data.status]);
    await loadCategories();
    go(`/admin/articles/${res.data.id}/edit`, true);
    return true;
  }

  function viewCategories() {
    if (!isAdmin()) return denied();
    const edit = S.categories.find((c) => String(c.id) === qs().get('edit')) || null;
    adminShell('Categories', `<div class="split"><section class="panel"><div class="panel__head"><h3>${edit ? 'Edit Category' : 'Add New Category'}</h3>${edit ? '<a href="/admin/categories">+ Add new instead</a>' : ''}</div>
  <form class="form" id="catForm"><label>Name<input name="name" required maxlength="60" value="${esc(edit ? edit.name : '')}" placeholder="e.g. Travel"></label>
  <label>Slug <small>(URL part — leave empty to auto-create)</small><input name="slug" value="${esc(edit ? edit.slug : '')}" placeholder="travel"></label>
  <label>Description<textarea name="description" rows="3" maxlength="300" placeholder="Shown on the category page and used as its Google description">${esc(edit ? edit.description : '')}</textarea></label>
  <label>Colour<input type="color" name="color" value="${esc(edit ? edit.color : '#6c4cff')}"></label>
  <button class="btn btn--accent">${edit ? 'Update Category' : 'Add New Category'}</button></form></section>
<section class="panel"><div class="panel__head"><h3>All categories (${S.categories.length})</h3></div><table class="tbl tbl--full"><thead><tr><th>Name</th><th>Slug</th><th>Articles</th><th></th></tr></thead><tbody>
  ${S.categories.map((c) => `<tr><td><span class="dot" style="--c:${esc(c.color)}"></span><b>${esc(c.name)}</b><small>${esc(c.description)}</small></td><td class="dim">${esc(c.slug)}</td><td>${c.count}</td>
  <td class="acts"><a href="/admin/categories?edit=${c.id}">Edit</a><a href="/category/${esc(c.slug)}" target="_blank">View</a><button class="del" data-del="${c.id}">Delete</button></td></tr>`).join('')}</tbody></table></section></div>`);
    document.getElementById('catForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const fd = new FormData(e.target);
      const name = fd.get('name').trim(); let slug = slugify(fd.get('slug').trim() || name);
      if (S.categories.some((c) => c.slug === slug && (!edit || c.id !== edit.id))) slug = `${slug}-${Date.now().toString(36).slice(-3)}`;
      const row = { name, slug, description: fd.get('description').trim(), color: /^#[0-9a-f]{6}$/i.test(fd.get('color')) ? fd.get('color') : '#6c4cff' };
      const { error } = edit ? await sb.from('categories').update(row).eq('id', edit.id) : await sb.from('categories').insert(row);
      if (error) return toast(error.message);
      flash('success', edit ? 'Category updated.' : `Category “${name}” added.`); await loadCategories(); go('/admin/categories');
    });
    app.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      const c = S.categories.find((x) => String(x.id) === b.dataset.del);
      if (!window.confirm(`Delete category “${c.name}”? Articles will stay but become uncategorized.`)) return;
      const { error } = await sb.from('categories').delete().eq('id', c.id);
      if (error) return toast(error.message);
      flash('success', 'Category deleted.'); await loadCategories(); route();
    }));
  }

  async function viewUsers() {
    if (!isAdmin()) return denied();
    const { data } = await sb.rpc('admin_users');
    adminShell('Users', `<section class="panel"><div class="panel__head"><h3>Registered writers (${(data || []).length})</h3></div><table class="tbl tbl--full">
  <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Articles</th><th>Joined</th></tr></thead><tbody>
  ${(data || []).map((u) => `<tr><td><span class="av av--sm">${esc(initials(u.name))}</span> <b>${esc(u.name)}</b></td><td class="dim">${esc(u.email)}</td>
  <td>${u.id === S.profile.id ? '<span class="pill pill--published">admin (you)</span>' : `<span class="inline"><select data-role="${u.id}"><option value="author" ${u.role === 'author' ? 'selected' : ''}>Author</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option></select></span>`}</td>
  <td><a href="/author/${u.id}" target="_blank">${u.posts}</a></td><td class="dim">${fmtDate(u.created_at)}</td></tr>`).join('')}</tbody></table></section>`);
    app.querySelectorAll('[data-role]').forEach((s) => s.addEventListener('change', async () => {
      const { error } = await sb.from('profiles').update({ role: s.value }).eq('id', s.dataset.role);
      toast(error ? error.message : 'Role updated.');
    }));
  }

  function viewSettings() {
    if (!isAdmin()) return denied();
    const st = S.settings;
    adminShell('Settings', `<form id="setForm" class="split"><section class="panel form"><div class="panel__head"><h3>Site identity</h3></div>
  <label>Site title<input name="site_title" value="${esc(st.site_title)}" maxlength="80"></label>
  <label>Tagline <small>(used as homepage meta description)</small><input name="tagline" value="${esc(st.tagline)}" maxlength="200"></label>
  <label>Footer text<input name="footer_text" value="${esc(st.footer_text)}" maxlength="300"></label>
  <div class="panel__head"><h3>Writers</h3></div>
  <label class="check"><input type="checkbox" name="allow_registration" ${st.allow_registration === '1' ? 'checked' : ''}> Anyone can create an account and write</label>
  <label class="check"><input type="checkbox" name="require_approval" ${st.require_approval === '1' ? 'checked' : ''}> New writers' articles need admin approval before going live <small>(recommended to stop spam)</small></label></section>
<section class="panel form"><div class="panel__head"><h3>Analytics & header code</h3></div>
  <p class="hint">Paste Google Analytics or similar tracking code here. It is added to every public page.<br><b>Google Search Console verification:</b> Google checks the raw HTML file, so the verification tag must be built into the site files — send the tag to your developer (or Claude) to add it, or use the “Google Analytics” verification method in Search Console once Analytics code is here.</p>
  <label>Code for &lt;head&gt;<textarea name="head_code" rows="8" class="mono" placeholder="<!-- Google tag (gtag.js) -->">${esc(st.head_code)}</textarea></label>
  <div class="seo-ok"><b>✓ Search engine friendly</b><ul><li>Pages are set to <code>index, follow</code> — no noindex tag on public pages</li>
  <li>Robots: <a href="/robots.txt" target="_blank">${esc(SITE)}/robots.txt</a> (includes your sitemap link)</li>
  <li>Sitemap (auto-updating): <a href="${esc(CFG.sitemapUrl)}" target="_blank">open sitemap</a> — submit this URL in Search Console</li>
  <li>Article schema, canonical URLs and Open Graph tags are added automatically</li></ul></div>
  <button class="btn btn--accent btn--lg">Save Settings</button></section></form>`);
    document.getElementById('setForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const f = e.target;
      const vals = { site_title: f.site_title.value.slice(0, 80), tagline: f.tagline.value.slice(0, 200), footer_text: f.footer_text.value.slice(0, 300), head_code: f.head_code.value.slice(0, 5000), allow_registration: f.allow_registration.checked ? '1' : '0', require_approval: f.require_approval.checked ? '1' : '0' };
      const { error } = await sb.from('settings').upsert(Object.entries(vals).map(([key, value]) => ({ key, value })));
      if (error) return toast(error.message);
      await loadSettings(); flash('success', 'Settings saved.'); route();
    });
  }

  function viewProfile() {
    const u = S.profile;
    adminShell('Your Profile', `<form id="profForm" class="split"><section class="panel form"><div class="panel__head"><h3>About you</h3></div>
  <label>Display name<input name="name" value="${esc(u.name)}" maxlength="80" required></label><label>Email<input value="${esc(u.email)}" disabled></label>
  <label>Author bio <small>(shown under your articles)</small><textarea name="bio" rows="4" maxlength="500">${esc(u.bio)}</textarea></label>
  <a href="/author/${u.id}" target="_blank">View your public author page ↗</a></section>
<section class="panel form"><div class="panel__head"><h3>Change password</h3></div>
  <label>New password <small>(min 8 characters, leave empty to keep)</small><input type="password" name="new_password" minlength="8" autocomplete="new-password"></label>
  <button class="btn btn--accent btn--lg">Save Profile</button></section></form>`);
    document.getElementById('profForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const f = e.target;
      const { error } = await sb.from('profiles').update({ name: f.name.value.trim().slice(0, 80) || u.name, bio: f.bio.value.trim().slice(0, 500) }).eq('id', u.id);
      if (error) return toast(error.message);
      if (f.new_password.value) {
        const r = await sb.auth.updateUser({ password: f.new_password.value });
        if (r.error) { flash('error', `Profile saved, but password not changed: ${r.error.message}`); await loadProfile(); return route(); }
      }
      await loadProfile(); flash('success', 'Profile updated.'); route();
    });
  }

  // ---------- router ----------
  let leaveGuard = null;
  function go(path, replace) {
    if (leaveGuard && !leaveGuard()) return;
    leaveGuard = null;
    history[replace ? 'replaceState' : 'pushState']({}, '', path);
    route();
  }
  window.CVSetLeaveGuard = (fn) => { leaveGuard = fn; };

  async function route() {
    if (window.CVEditor) window.CVEditor.unmount();
    const p = location.pathname.replace(/\/+$/, '') || '/';
    let m;
    window.scrollTo(0, 0);
    if (p.startsWith('/admin') && !S.profile) { flash('error', 'Please log in to continue.'); return go(`/login?next=${encodeURIComponent(p + location.search)}`, true); }
    if (p.startsWith('/admin')) { setTheme(true); app.innerHTML = '<div class="loading">Loading…</div>'; }
    try {
      if (p === '/') return await viewHome();
      if ((m = p.match(/^\/category\/([\w-]+)$/))) return await viewCategory(m[1]);
      if ((m = p.match(/^\/article\/([\w-]+)$/))) return await viewArticle(m[1]);
      if ((m = p.match(/^\/author\/([0-9a-f-]{36})$/))) return await viewAuthor(m[1]);
      if (p === '/search') return await viewSearch();
      if (p === '/login') return viewAuth('login');
      if (p === '/register') return viewAuth('register');
      if (p === '/admin') return await viewDashboard();
      if (p === '/admin/articles') return await viewArticlesList();
      if (p === '/admin/articles/new') return await viewEditor(null);
      if ((m = p.match(/^\/admin\/articles\/(\d+)\/edit$/))) return await viewEditor(parseInt(m[1], 10));
      if (p === '/admin/categories') return viewCategories();
      if (p === '/admin/users') return await viewUsers();
      if (p === '/admin/settings') return viewSettings();
      if (p === '/admin/profile') return viewProfile();
      return viewNotFound();
    } catch (err) {
      console.error(err);
      app.innerHTML = `<div class="loading">Something went wrong: ${esc(err.message || err)}. <a href="/">Go home</a></div>`;
    }
  }

  document.addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (!a || a.target || a.hasAttribute('download') || a.hasAttribute('data-noroute') || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin) return;
    if (url.pathname === location.pathname && url.hash && !url.search) return;
    if (/\.(xml|txt|html|svg|png|jpe?g)$/.test(url.pathname)) return;
    e.preventDefault();
    go(url.pathname + url.search);
  });
  document.addEventListener('submit', (e) => {
    if (!e.target.matches('[data-search]')) return;
    e.preventDefault();
    const q = e.target.q.value.trim();
    go(`/search?q=${encodeURIComponent(q)}`);
  });
  window.addEventListener('popstate', route);

  function injectHeadCode() {
    const code = S.settings.head_code;
    if (!code) return;
    const tpl = document.createElement('template'); tpl.innerHTML = code;
    tpl.content.childNodes.forEach((n) => {
      if (n.nodeName === 'SCRIPT') { const s = document.createElement('script'); [...n.attributes].forEach((at) => s.setAttribute(at.name, at.value)); s.text = n.textContent; document.head.appendChild(s); }
      else if (n.nodeType === 1) document.head.appendChild(n.cloneNode(true));
    });
  }

  sb.auth.onAuthStateChange((event) => {
    if (event === 'SIGNED_OUT') S.profile = null;
    if (event === 'PASSWORD_RECOVERY') { flash('success', 'Set your new password below.'); }
  });

  (async () => {
    try {
      await Promise.all([loadSettings(), loadCategories(), loadProfile()]);
    } catch (e) { console.error(e); }
    injectHeadCode();
    route();
  })();
}());
