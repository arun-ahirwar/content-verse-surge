// Public Supabase settings (the publishable key is safe in the browser; data is protected by Row Level Security)
window.CV_CONFIG = {
  url: 'https://mglpwuymoqfudllwcxhn.supabase.co',
  key: 'sb_publishable_fbKbcB77W19ZU2yberHi0Q_RACN8dkO',
  siteUrl: 'https://content-verse.surge.sh',
  sitemapUrl: 'https://mglpwuymoqfudllwcxhn.supabase.co/rest/v1/rpc/sitemap?apikey=sb_publishable_fbKbcB77W19ZU2yberHi0Q_RACN8dkO',
};
