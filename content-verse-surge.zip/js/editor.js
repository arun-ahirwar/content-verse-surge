/* Content Verse — classic editor (WordPress-style) on TinyMCE */
(function () {
  const $ = (id) => document.getElementById(id);
  let dirty = false;
  const unload = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };

  window.CVEditor = {
    unmount() {
      if (window.tinymce && tinymce.get('content')) tinymce.get('content').remove();
      window.removeEventListener('beforeunload', unload);
      dirty = false;
    },
    mount(opts) {
  const uploadImage = opts.uploadImage;
  const form = $('postForm');
  dirty = false;

  function updateWordCount(text) {
    const n = (text || '').trim().split(/\s+/).filter(Boolean).length;
    $('wc').textContent = `Word count: ${n}`;
  }

  tinymce.init({
    selector: '#content',
    license_key: 'gpl',
    base_url: '/vendor/tinymce',
    suffix: '.min',
    menubar: false,
    branding: false,
    promotion: false,
    min_height: 520,
    plugins: 'lists link image media table code fullscreen charmap wordcount searchreplace autoresize anchor preview',
    autoresize_bottom_margin: 40,
    max_height: 1100,
    toolbar_mode: 'wrap',
    toolbar: [
      'blocks | bold italic | bullist numlist | blockquote | alignleft aligncenter alignright | link unlink | image media | fullscreen | cvadv',
      'strikethrough underline hr | forecolor backcolor | pastetext removeformat | charmap | outdent indent | table | searchreplace | undo redo | code preview',
    ],
    block_formats: 'Paragraph=p; Heading 2=h2; Heading 3=h3; Heading 4=h4; Heading 5=h5; Heading 6=h6; Preformatted=pre',
    content_style: `body{font-family:Georgia,serif;font-size:18px;line-height:1.75;color:#2a2440;margin:18px 24px}
      h2,h3,h4{font-family:Georgia,serif;color:#17122b} img{max-width:100%;height:auto;border-radius:10px}
      blockquote{border-left:4px solid #ff5a36;margin:1em 0;padding-left:18px;font-style:italic}
      table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:8px}`,
    image_caption: true,
    image_advtab: true,
    image_title: true,
    automatic_uploads: true,
    paste_data_images: true,
    relative_urls: false,
    remove_script_host: true,
    convert_urls: true,
    link_default_target: '_blank',
    link_assume_external_targets: 'https',
    images_upload_handler: (blobInfo) => uploadImage(new File([blobInfo.blob()], blobInfo.filename(), { type: blobInfo.blob().type })),
    file_picker_types: 'image',
    file_picker_callback: (cb) => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*';
      inp.onchange = async () => {
        try { const url = await uploadImage(inp.files[0]); cb(url, { alt: inp.files[0].name.replace(/\.[^.]+$/, '') }); } catch (e) { alert(e.message); }
      };
      inp.click();
    },
    setup: (ed) => {
      // "Toolbar Toggle" — just like WordPress' kitchen sink button
      ed.ui.registry.addToggleButton('cvadv', {
        icon: 'more-drawer',
        tooltip: 'Toolbar Toggle',
        onAction: (api) => {
          const c = ed.getContainer();
          c.classList.toggle('cv-adv-off');
          api.setActive(!c.classList.contains('cv-adv-off'));
          try { localStorage.setItem('cv-adv', c.classList.contains('cv-adv-off') ? '0' : '1'); } catch (e) { /* ignore */ }
        },
        onSetup: (api) => {
          let on = true;
          try { on = localStorage.getItem('cv-adv') !== '0'; } catch (e) { /* ignore */ }
          if (!on) ed.getContainer().classList.add('cv-adv-off');
          api.setActive(on);
        },
      });
      ed.on('init', () => updateWordCount(ed.getContent({ format: 'text' })));
      ed.on('input change keyup SetContent', () => { dirty = true; updateWordCount(ed.getContent({ format: 'text' })); });
    },
  });

  // Visual / Text tabs
  document.querySelectorAll('.vt button').forEach((b) => b.addEventListener('click', () => {
    const ed = tinymce.get('content');
    if (!ed) return;
    document.querySelectorAll('.vt button').forEach((x) => x.classList.toggle('on', x === b));
    if (b.dataset.mode === 'text') { ed.hide(); $('content').classList.add('htmlmode'); } else { ed.show(); $('content').classList.remove('htmlmode'); }
  }));
  $('content').addEventListener('input', (e) => { dirty = true; updateWordCount(e.target.value.replace(/<[^>]+>/g, ' ')); });

  // Add Media button
  $('addMedia').addEventListener('click', () => $('mediaFile').click());
  $('mediaFile').addEventListener('change', async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const btn = $('addMedia'); btn.disabled = true; btn.lastChild.textContent = ' Uploading…';
    try {
      const url = await uploadImage(f);
      const alt = f.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ');
      const html = `<p><img src="${url}" alt="${alt.replace(/"/g, '')}"></p>`;
      const ed = tinymce.get('content');
      if (ed && !ed.isHidden()) ed.insertContent(html);
      else { const ta = $('content'); ta.setRangeText(html, ta.selectionStart, ta.selectionEnd, 'end'); }
      dirty = true;
    } catch (err) { alert(err.message); }
    btn.disabled = false; btn.lastChild.textContent = ' Add Media'; e.target.value = '';
  });

  // Featured image
  function setFeatured(url) {
    $('featured_image').value = url || '';
    $('fimgPreview').innerHTML = url ? `<img src="${url}" alt="">` : '';
    $('fimgSet').textContent = url ? 'Replace featured image' : 'Set featured image';
    $('fimgRemove').hidden = !url;
    dirty = true;
  }
  $('fimgSet').addEventListener('click', () => $('fimgFile').click());
  $('fimgPreview').addEventListener('click', () => $('fimgFile').click());
  $('fimgRemove').addEventListener('click', () => setFeatured(''));
  $('fimgFile').addEventListener('change', async (e) => {
    const f = e.target.files[0]; if (!f) return;
    $('fimgSet').textContent = 'Uploading…';
    try { setFeatured(await uploadImage(f)); } catch (err) { alert(err.message); setFeatured($('featured_image').value); }
    e.target.value = '';
  });
  $('fimgUrl').addEventListener('change', (e) => { if (/^https?:\/\//.test(e.target.value.trim())) setFeatured(e.target.value.trim()); });

  // Slug + SEO preview
  const slugify = (s) => s.toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90);
  let slugTouched = !!$('slug').value;
  $('slug').addEventListener('input', () => { slugTouched = true; $('serpSlug').textContent = $('slug').value || '…'; });
  $('title').addEventListener('input', () => {
    dirty = true;
    if (!slugTouched) { $('slug').value = slugify($('title').value); $('serpSlug').textContent = $('slug').value || '…'; }
    if (!$('meta_title').value) $('serpTitle').textContent = $('title').value || 'Your article title';
  });
  $('meta_title').addEventListener('input', (e) => { $('serpTitle').textContent = e.target.value || $('title').value || 'Your article title'; });
  $('meta_description').addEventListener('input', (e) => { $('serpDesc').textContent = e.target.value || 'Your meta description will appear here in Google search results.'; });
  document.querySelectorAll('.cnt').forEach((c) => {
    const el = $(c.dataset.for); const max = +c.dataset.max;
    const upd = () => { const n = el.value.length; c.textContent = `${n}/${max}`; c.classList.toggle('over', n > max); };
    el.addEventListener('input', upd); upd();
  });
  form.querySelectorAll('input, textarea, select').forEach((el) => el.addEventListener('change', () => { dirty = true; }));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.submitter; const action = (btn && btn.dataset.action) || 'draft';
    const ed = tinymce.get('content'); if (ed && !ed.isHidden()) ed.save();
    const fd = new FormData(form); const fields = Object.fromEntries(fd.entries());
    form.querySelectorAll('button[type=submit]').forEach((b) => { b.disabled = true; });
    if (btn) btn.dataset.label = btn.textContent, btn.textContent = 'Saving…';
    dirty = false;
    const ok = await opts.onSave(fields, action);
    if (!ok) { form.querySelectorAll('button[type=submit]').forEach((b) => { b.disabled = false; }); if (btn) btn.textContent = btn.dataset.label; dirty = true; }
  });
  const trash = $('trash'); if (trash) trash.addEventListener('click', () => { dirty = false; opts.onTrash(); });
  window.addEventListener('beforeunload', unload);
  window.CVSetLeaveGuard(() => !dirty || window.confirm('You have unsaved changes. Leave this page?'));
    },
  };
}());
